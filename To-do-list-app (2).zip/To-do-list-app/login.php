<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="styles/todo-list.css" type = "text/css">
        <title>LOGIN</title>
    </head>

    <body>
        <?php include('ToDoHeader.php')?>

        <div class = "container">
            <div class = "login">
            <h2> Log In </h2><br>

                <form action = "backend/LoginMain.inc.php" method = "post">
                <label for ="email"> Email:<br></label>
                <input type="text" id="email" name="email" required><br><br>
                <label for ="password">Password:<br></label>
                <input type="password" id="password" name="password" required><br><br>
                <button type = "submit" name = "login-submit">Login </button>
                    
                </form>
            </div>
        </div>

    </body>


</html>