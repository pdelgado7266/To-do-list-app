<?php
session_start();

if (!isset($_SESSION['user_id'])){
	header("Location: login.php");
	exit;
}

if(isset($_POST['taskName'],$_POST['priority'], $_POST['dueDate'],$_POST['userId'],$_POST['taskList'])){

$taskName = $_POST['task'];
$priority = $_POST['priority'];
$dueDate = $_POST['dueDate'];
$userId = $_POST['user_id'];
$taskList=$_POST['taskList'];
$label=$_POST['label'];



include 'Connectmain.php';

$userId = $_SESSION['user_id'];


 
 $sql = "INSERT INTO tasks (task, due_date, priority, label, task_list_id) VALUES (?,?,?,?,?)";
 $stmt = $conn->prepare($sql);
 $stmt->bind_param("siisi", $taskName,$dueDate, $priority,$label,$taskList);
 $stmt->execute();
 
 $stmt->close();
 $conn->close();


}else{
	echo "Missing required POST data";
	exit();
}
?>
 