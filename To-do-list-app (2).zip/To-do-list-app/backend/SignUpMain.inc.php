<?php
if (isset($_POST['signup-submit']))
{
	
	require 'Connectmain.php';
	
	$email = $_POST['email'];
	$password = $_POST['password'];
	$passwordRepeat =$_POST['passwordRepeat'];
	
	if(empty($email) || empty($password) || empty($passwordRepeat)){
		header("Location: ../signup.php?error=emptyfields&mail=".$email);
		exit();
	}
	else if($password !== $passwordRepeat){ 
		header("Location: ../signup.php?error=passwordcheck&username=".$email);
		exit();
	}
	else{
		$sql ="INSERT INTO users (email, password) VALUES(?,?)";
		$stmt = mysqli_prepare($conn, $sql);
			if(!$stmt){
				header("Location:../signup.php?error=sqlerror");
				exit();
		}
		else{
			$hashedPwd = password_hash($password, PASSWORD_DEFAULT);
		
			mysqli_stmt_bind_param($stmt, "ss", $email,$hashedPwd);
			mysqli_stmt_execute($stmt);
			mysqli_stmt_store_result($stmt);
			mysqli_stmt_close($stmt);
			header("Location:../login.php?signup=success");
			exit();
		}
		
	}
		
	
	mysqli_close($conn);
	
}
else{
	header("Location: ../signup.php");
	exit();
}
	
	
?>
