<?php
	session_start();
?>

<header>
		<nav>
			<div class= "logo">
				<p> ToDo-List </P>
			</div>

			<ul>
				<li><a href = "todo-list.php"> List </a></li>
				<li><a href = "login.php"> Log in </a></li>
				<li><a href = "Signup.php">Sign up </a></li>
			</ul>

		</nav>

</header>
