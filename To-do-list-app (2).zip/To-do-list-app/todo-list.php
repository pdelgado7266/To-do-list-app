<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/todo-list.css" type = "text/css">
    <title>To-Do List</title>
</head>
<body>
    <?php include('ToDoHeader.php')?>

    <div class="listcontainer">
        <h1>To-Do List</h1>
        <input type="text" id="taskInput" placeholder="Add a new task"></br>
        <button id="advancedButton" onclick="toggleAdvanced()">
            <span>Advanced Options</span>
            <span class="arrow">&#11206;</span>
        </button>
        <div id="advanced">
            <label for="label">Label:</label>
            <input list="label" name="label" />
            <datalist id="label">
                
            </datalist></br>

            <label for="priority">Priority:</label>
            <select id="priority" name="priority">
                <option value="low">&#128998 Low</option>
                <option value="normal">&#129001 Normal</option>
                <option value="high">&#129000 High</option>
                <option value="urgent">&#9888 Urgent</option>
            </select></br>

            <label for="dueDate">Due Date:</label>
            <input type="date" id="dueDate" name="dueDate">
			
			
        </div>
        <button onclick="addTask()">Add</button>
	

        <ul id="taskList">
            
        </ul>
    </div>

    <script src="todo-list.js"></script>
	
	<script>
		function saveTaskList(){
			var userId = '<?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '0'; ?>';userId = String(userId).trim(); 
			userId = String(userId).trim(); 
			var taskList = document.getElementById('taskList').innerHTML;
			var taskInput= document.getElementById('taskInput').value;
			var priority = document.getElementById('priority').value;
			var dueDate = document.getElementById('dueDate').value;
			var label = document.getElementById('label').value;
			
		if (taskInput.trim()=== '' || priority.trim() ==='' || dueDate.trim() === '' || userId.trim() === ''){
		console.error("Missing required data");
		return;
		}
			$.ajax({
				type: "POST",
				url: "Task.php",
				data:{
					userId: userId,
					taskName: taskInput,
					priority: priority,
					dueDate: dueDate,
					taskList: taskList,
					label: label
				},
				
				success: function(response){
					console.log("Task list saved successfully.");
				},
				error:function(xhr,status,error){
					console.error("Error saving task list:",xhr.responseText);
				}
			});
			
		}
		</script>
		
		<?php
		function getTaskList($userId){}
		function saveTaskList($userId, $taskListData){}
		function deleteTaskList($userId){}
		?>
		
			
			
		
</body>
</html>
