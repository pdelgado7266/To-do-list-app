<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="styles/todo-list.css" type = "text/css">
        <title>SIGN-UP</title>
    </head>

    <body>
        <?php include('ToDoHeader.php')?>

        <?php
        include_once 'backend/connectMain.php'
        ?>
        
        <div class= signup_container>
            <div class = signup>
                <form class= "form-signup" action ="backend/SignUpMain.inc.php" method ="post">
                    <label for = "username"> Email:</label><br>
                    <input type = "text" id="username" name= "email"> <br>
                    <label for = "password"> Password: </label> <br>
                    <input type="text"  id="password" name="password"><br>
                    <label for ="confirm"> Confirm Password: </label><br>
                    <input type = " text" id="confirm" name ="passwordRepeat"><br>
                    <button type = "submit" name ="signup-submit"> Signup </button>
            </div>
        </div>

        </form>

    </body>



</html>